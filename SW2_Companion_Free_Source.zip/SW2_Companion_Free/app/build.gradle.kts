plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "ro.sw2companion"
    compileSdk = 35
    defaultConfig {
        applicationId = "ro.sw2companion"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
