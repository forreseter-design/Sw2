package ro.sw2companion

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.BatteryManager
import android.widget.*
import android.graphics.Color
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var results: TextView
    private var scanner: BluetoothLeScanner? = null
    private val found = linkedMapOf<String, String>()
    private val requestCode = 44

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(15, 20, 30)
        window.navigationBarColor = Color.rgb(15, 20, 30)
        buildUi()
        refreshInfo()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 34, 24, 28)
            setBackgroundColor(Color.rgb(15, 20, 30))
        }
        fun heading(t: String, size: Float = 22f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(Color.WHITE)
            setPadding(0, 12, 0, 10)
        }
        fun body(t: String) = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(Color.rgb(205, 215, 230))
            setPadding(0, 5, 0, 10)
        }
        fun button(t: String, action: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { action() }
        }
        layout.addView(heading("SW2 Companion", 28f))
        layout.addView(body("Companion neoficial pentru Sony SmartWatch 2 • Android modern"))
        layout.addView(heading("Telefon"))
        status = body("Se citesc informatiile…")
        layout.addView(status)
        layout.addView(button("Actualizeaza bateria si ora") { refreshInfo() })
        layout.addView(heading("Bluetooth"))
        layout.addView(body("Scanare BLE pasiva: cauta dispozitivele din apropiere. Nu trimite comenzi si nu modifica ceasul."))
        layout.addView(button("Scaneaza dispozitive Bluetooth") { startScan() })
        results = body("Niciun rezultat inca.")
        layout.addView(results)
        layout.addView(heading("Instrumente"))
        layout.addView(body("Previzualizare cadran 220 × 176 • prototip local"))
        layout.addView(WatchPreview(this))
        layout.addView(body("Ceas mondial: " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()) +
                "\nData: " + SimpleDateFormat("EEE, dd MMM yyyy", Locale.getDefault()).format(Date())))
        layout.addView(heading("Limitari importante"))
        layout.addView(body("Aceasta prima versiune verifica Bluetooth si afiseaza informatii locale. Nu pretinde ca trimite notificari sau cadrane pe SW2. Protocolul proprietar Sony trebuie identificat si testat separat inainte de a activa sincronizarea."))
        scroll.addView(layout)
        setContentView(scroll)
    }

    private fun refreshInfo() {
        val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val level = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        status.text = "Baterie telefon: ${if (level >= 0) "$level%" else "indisponibila"}\nOra locala: $time\nAndroid: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nModel: ${Build.MODEL}"
    }

    private fun startScan() {
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(
            Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT
        ) else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), requestCode)
            return
        }
        doScan()
    }

    private fun doScan() {
        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter: BluetoothAdapter? = manager.adapter
        if (adapter == null || !adapter.isEnabled) {
            results.text = "Bluetooth nu este disponibil sau este oprit."
            return
        }
        scanner = adapter.bluetoothLeScanner
        if (scanner == null) {
            results.text = "Scanarea BLE nu este disponibila pe acest telefon."
            return
        }
        found.clear()
        results.text = "Scanare in curs (10 secunde)…"
        try {
            scanner?.startScan(callback)
            results.postDelayed({
                try { scanner?.stopScan(callback) } catch (_: SecurityException) {}
                results.text = if (found.isEmpty()) "Nu au fost gasite dispozitive BLE.\nVerifica Bluetooth si permisiunile." else
                    found.values.joinToString("\n\n")
            }, 10000)
        } catch (e: SecurityException) {
            results.text = "Permisiune Bluetooth refuzata: ${e.message}"
        } catch (e: Exception) {
            results.text = "Eroare la scanare: ${e.message}"
        }
    }

    private val callback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d: BluetoothDevice = result.device
            val name = try { d.name ?: "Dispozitiv fara nume" } catch (_: SecurityException) { "Dispozitiv Bluetooth" }
            val address = try { d.address } catch (_: SecurityException) { "adresa ascunsa" }
            found[address] = "$name\n$address • RSSI ${result.rssi} dBm"
            runOnUiThread { results.text = found.values.joinToString("\n\n") }
        }
        override fun onScanFailed(errorCode: Int) {
            runOnUiThread { results.text = "Scanare esuata. Cod: $errorCode" }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == this.requestCode && grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }) doScan()
        else if (requestCode == this.requestCode) results.text = "Permisiunile Bluetooth nu au fost acordate."
    }

    override fun onDestroy() {
        try { scanner?.stopScan(callback) } catch (_: Exception) {}
        super.onDestroy()
    }
}

private class WatchPreview(context: Context) : View(context) {
    private val p = android.graphics.Paint(3)
    override fun onDraw(c: android.graphics.Canvas) {
        super.onDraw(c)
        val w = width.toFloat(); val h = (w * 176f / 220f).coerceAtMost(260f)
        val left = 0f; val top = 0f
        p.color = Color.rgb(4, 7, 12); c.drawRoundRect(left, top, w, h, 18f, 18f, p)
        p.color = Color.rgb(55, 130, 220); c.drawCircle(w/2, h/2, h*0.34f, p)
        p.color = Color.rgb(4, 7, 12); c.drawCircle(w/2, h/2, h*0.29f, p)
        p.color = Color.WHITE; p.textAlign = android.graphics.Paint.Align.CENTER; p.textSize = h*0.24f
        c.drawText(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()), w/2, h*0.55f, p)
        p.textSize = h*0.09f; p.color = Color.LTGRAY
        c.drawText(SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(Date()), w/2, h*0.72f, p)
    }
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(w, (w * 176f / 220f).toInt().coerceAtMost(260))
    }
}
