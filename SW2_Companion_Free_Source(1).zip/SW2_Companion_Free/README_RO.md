# SW2 Companion – proiect gratuit

Aceasta este o prima versiune Android nativa, fara modificari de firmware si fara abonamente.
Include:
- informatii despre telefon, baterie si ora;
- scanare BLE cu permisiunile Android moderne;
- previzualizare locala de cadran 220×176.

**Important:** nu este inca o aplicatie completa de sincronizare Sony SmartWatch 2. Protocolul proprietar SW2 nu este implementat/verificat; aplicatia nu pretinde ca trimite notificari sau cadrane catre ceas.

## Cum obtii APK-ul gratuit

1. Descarca arhiva si dezarhiveaz-o.
2. Creeaza un repository nou pe GitHub (recomandat Public pentru a evita limita lunara de minute Actions pe repository privat).
3. Incarca toate fisierele si folderele din arhiva in repository, pe ramura `main`.
4. Deschide tab-ul **Actions**. Workflow-ul **Build Android APK** va porni automat; daca nu, alege **Run workflow**.
5. Dupa finalizare, deschide rularea reusita si descarca artifact-ul **SW2-Companion-APK**.
6. Dezarhiveaza artifact-ul; fisierul `app-debug.apk` se instaleaza pe telefon. Android poate cere permisiunea de instalare din sursa folosita.

Nu sunt necesare card bancar, Replit sau servicii cu abonament. Pentru un repository privat, GitHub poate aplica limite de minute gratuite.

## Cerinte

- Android 6.0+ (minSdk 23)
- Bluetooth pentru scanarea BLE
- Internet doar pentru eventuale functii online viitoare; aceasta versiune nu transmite date catre un server.

## Urmatoarea etapa tehnica

Dupa instalare, verificam daca SW2 apare in scanare. BLE scanarea nu garanteaza compatibilitatea: SmartWatch 2 foloseste un protocol Sony proprietar, iar conectarea si transferul de date necesita analiza separata.
